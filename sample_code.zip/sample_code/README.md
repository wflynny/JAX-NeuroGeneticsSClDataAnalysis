Note: this is a preliminary version of the scalpel package which is currently
privately under development
[here](https://www.github.com/TheJacksonLaboratory/scalpel.git).


Single Cell AnaLysis PipELine (scalpel)
=======================================

This is a packagified version of Jupyter notebooks that have been used to
conduction exploratory data analysis of single cell RNA-seq data produced by the
JAX Single Cell Biology Laboratory.  The ultimate goal of this package is to
output an .Rds file containing expression, clustering, and feature data for use
in [CellView][1].

The motivation for creating this package is so that there can be a standard set
of functions to be called from various notebooks by different users.  Currently,
the standard operating procedure is to copy and modify notebooks as needed, but
that can impede reproducibility over the long run if those notebooks are not
maintained.

Warning
-------
This package is active under development; the package is subject to change at
any time.  Open an issue if something is broken or contact me at
`bill.flynn@jax.org`.


Authorship
----------

As of the initial version, all functions are slightly modified (mostly for py2
-> py3 conversion) functions written by [Mohan Bolisetty][2] and have only been
changed such that they function together as a python package.  However,
development of additional functionality is underway.

Installation
------------

Currently you can install with `conda`, `git` and `pip`.  The main thing you
need from `conda` is the `rpy2` package, which is used to generate `.Rds` files
for use in CellView.  My attempts to get rpy2 installed via `pip` vary from
machine to machine, and I've found installation through conda works best.

First, run

```bash
$ conda install rpy2
```

Then, run

```bash
$ git clone https://github.com/TheJacksonLaboratory/scalpel
$ cd scalpel
$ pip install .
$ pip install -r requirements.txt
```

The installation requires the initialization of the [original BH t-SNE][3]
implementation via a `git submodule` call in `setup.py`.  If you install with
the above command, the `bhtsne_lvdm` directory will not be initialized as pip
installs in a temporary dictionary.  The installation should work fine but you
can check by running t-SNE with the `tsne_mod='bhtsne_lvdm'` keyword.  If it
can't find the `bh_tsne binary`, it will error saying exactly that.  However, if
you install in `develop` mode, e.g.

```bash
pip install -e .
# or
python setup.py develop
```

the `bhtsne_lvdm` module in the current directory will be cloned and you can
verify that the binary is built correctly.

**If you have problems with installation, please open an issue, come find me in
B400, or send me an email at `bill.flynn@jax.org`.**

Usage
-----

An example use case is located in the [`examples/ExampleNotebook.ipynb`][4]
Jupyter/iPython notebook.

Roadmap
-------

- [ ] Fix plotting, especially transcripts/umis per cell plots
- [x] Update and remove errors from `ExampleNotebook.ipynb`
- [ ] Add testing suite
- [ ] Validate clustering methodology
- [ ] Test umap/hdbscan
- [ ] Clean up marker identification code
- [ ] Add additional functionality for plate-based analyses

[1]: https://github.com/mohanbolisetty/CellView
[2]: https://github.com/mohanbolisetty
[3]: https://github.com/lvdmaaten/bhtsne
[4]: examples/ExampleNotebook.ipynb
