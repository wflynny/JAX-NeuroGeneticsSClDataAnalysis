import os
from subprocess import run
from setuptools import setup


PACKAGE_NAME = 'scalpel'

VERSION = '0.1.0'


def readme():
    with open('README.md') as readme_file:
        return readme_file.read()


def build_submodules():
    # clone
    if not os.path.exists('bhtsne_lvdm/README.md'):
        init_cmd = 'git submodule update --init'
        print("LvdM BH t-SNE git submodule is not cloned yet, will invoke "
              f"'{init_cmd}' now.")
        output = run(init_cmd.split())
        if output.returncode:
            raise Exception(f"'{init_cmd}' failed!")
    else:
        print("LvdM BH t-SNE git submodule already initialized!")

    # compile
    binary_path = 'bhtsne_lvdm/bh_tsne'
    if not os.path.exists(binary_path):
        os.chdir('bhtsne_lvdm')
        compile_cmd = 'g++ sptree.cpp tsne.cpp tsne_main.cpp -o bh_tsne -O2'
        output = run(compile_cmd.split())
        if output.returncode:
            raise Exception(f"'{compile_cmd}' failed!")
        else:
            print(f"Successfully compiled binary [{binary_path}].")
        os.chdir('..')
        assert os.path.exists(binary_path), \
               f"[{binary_path}] binary doens't exist!"
    else:
        print(f"bhtsne binary [{binary_path}] already exists. "
              "Will not compile it again.")

build_submodules()

configuration = {
    'name' : PACKAGE_NAME,
    'version': VERSION,
    'description' : 'Single Cell core AnaLysis PipELine',
    'long_description' : readme(),
    'classifiers' : [
        'Development Status :: 3 - Alpha',
        'Intended Audience :: Science/Research',
        'Intended Audience :: Developers',
        'License :: OSI Approved',
        'Programming Language :: Python',
        'Topic :: Software Development',
        'Topic :: Scientific/Engineering',
        'Operating System :: POSIX',
        'Operating System :: Unix',
        'Operating System :: MacOS',
        'Programming Language :: Python :: 3.6',
    ],
    'keywords' : 'scRNA-seq single cell cellview jax',
    'url' : 'http://github.com/TheJacksonLaboratory/scalpel',
    'maintainer' : 'Bill Flynn',
    'maintainer_email' : 'bill.flynn@jax.org',
    'license' : 'LGPL-3.0+',
    'packages' : ['scalpel', 'scalpel.common'],
    'install_requires' : ['Cython', 'rpy2',
                          'pandas >= 0.20',
                          'scikit-learn >= 0.18',
                          'scipy >= 0.19',
                          'numpy >= 1.13',
                          'statsmodels',
                          'hdbscan',
                          'umap-learn >= 0.2.1',
                          'matplotlib >= 2.0.0',
                          'seaborn',
                          'plotly'],
    'dependency_links': ['git+https://github.com/DmitryUlyanov/Multicore-TSNE.git',
                         'git+https://github.com/dominiek/python-bhtsne.git'],
    'ext_modules' : [],
    'cmdclass' : {},
    'test_suite' : '',
    'tests_require' : [],
    'data_files' : ()}


setup(**configuration)
