"""
This module contains functions to analysis single cell RNA sequencing expression
data that is output from cellranger and drop-seq_tools.  The functionality
includes:

- create a DataFrame from a 10X genomics count gene-barcode counts matrix
- select highly variable genes
- reduce data dimensionality via t-SNE and other methods
- cluster data in reduced dimensionality space with DBSCAN and HDBSCAN
- save cluster/t-SNE/expression data in an .Rds file for use in CellView
- various plotting functionality

The original author of this module is

    Mohan Bolisetty (mby, mohan.bolisetty@jax.org)

He wrote these functions in an iPython/Jupyter notebook and I translated them to
this module so that they can be (a) imported into other scripts in addition to
notebooks and (b) version controlled.

An example notebook running these commands can be found here:

    examples/ExampleNotebook.ipynb

author: Mohan Bolisetty (mohan.bolisetty@jax.org)
author: Bill Flynn (bill.flynn@jax.org)
"""
from scalpel.common import *
from scalpel.random import RANDOMSTATE
from scalpel.read_write import write_rds, read_10X, savefig, \
                               write_auc_to_excel, compute_mean_expression
from scalpel.qc import normalize_expression, \
                       median_umis_per_cell, median_genes_per_cell, \
                       find_overdispersed_genes, \
                       find_variable_genes
from scalpel.clust_redux import run_pca, run_tsne, run_dbscan, run_hdbscan, run_umap, \
                                DBSCANSweeper, HDBSCANSweeper
from scalpel.identify import identify_markers, classify_cells
from scalpel.plotting import set_plotting_style, \
                             plot_qc, plot_qc_violins, \
                             plot_expression, plot_clusters, plot_clusters_3d, \
                             plot_marker_heatmap
