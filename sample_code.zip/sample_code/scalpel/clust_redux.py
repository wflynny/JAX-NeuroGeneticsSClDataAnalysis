"""
This module contains a generalized class for handling scRNA-seq dimensionality
reduction and clustering algorithms
"""
from .common import *
from site import getsitepackages
from subprocess import run as sprun
from tempfile import NamedTemporaryFile as ntf
from itertools import product

from sklearn import metrics
from sklearn.cluster import DBSCAN
from sklearn.manifold import TSNE as sklearnTSNE
from sklearn.decomposition import PCA as sklearnPCA

from umap import UMAP
from hdbscan import HDBSCAN
from bhtsne import tsne as bh_tsne_pip
from bhtsne_lvdm.bhtsne import run_bh_tsne as bh_tsne_lvdm
from MulticoreTSNE import MulticoreTSNE as multicore_tsne

from .random import RANDOMSTATE


def _multicore_tsne(X, **kwds):
    tsne = multicore_tsne(**kwds)
    return tsne.fit_transform(X)


def _sklearn_tsne(X, **kwds):
    tsne = sklearnTSNE(**kwds)
    return tsne.fit_transform(X)


def _bh_tsne_lvdm(X, **kwds):
    is_interactive = True
    try:
        __IPYTHON__
    except NameError:
        is_interactive = False

    if not is_interactive:
        print("Launching noninteractive `bhtsne_lvdm` via import.")
        bh_tsne_lvdm(X, **kwds)
    else:
        # Needed because LvdM-BHTSNE can't be run in Jupyter/iPython notebooks
        print("Attempting to launching 'interactive' `bhtsne_lvdm` "
              "via subprocess.")
        with ntf() as tmp_X, ntf() as tmp_Y:
            np.savetxt(tmp_X.name, X)
            # installed via pip install
            src_path = os.path.join(getsitepackages()[0], 'scalpel')
            if not os.path.exists(src_path):
                try:
                    egg_path = os.path.join(getsitepackages()[0],
                                            'scalpel.egg-link')
                    with open(egg_path, 'r') as fin:
                        src_path = fin.readlines()[0].strip()
                except e:
                    raise e
            bhtsne_path = os.path.join(src_path, 'bhtsne_lvdm', 'bhtsne.py')
            cmd = [bhtsne_path, '-d', f'{kwds.get("no_dims")}', '-i',
                   f'{tmp_X.name}', '--no_pca', '-r', f'{kwds.get("randseed")}',
                   '-m', f'{kwds.get("niter")}', '-o', f'{tmp_Y.name}']
            output = sprun(cmd)
            output.check_returncode()
            tsne = np.loadtxt(tmp_Y.name)
        return tsne


def _bh_tsne(X, **kwds):
    return bh_tsne_pip(X, **kwds)


def run_tsne(data, genes=None, tsne_mod="bhtsne", ndims=3, ncores=1,
             niter=2500, **kwargs):
    """
    Computes t-SNE dimensionality reduction to 3 dimensions.

    Parameters
    ----------
    data : pd.dataframe of shape (n_features, n_samples)
        DataFrame which will be transformed using `data.T.values`

    genes : array, list, or pd.Index of shape (n_genes <= n_features), optional
        Genes to subsample from the dataframe, e.g. `data.loc[genes]`

    tsne_mod : str, optional
        Specifies what package to use to compute the t-SNE embedding:
        - "bhtsne_lvdm"    : https://github.com/lvdmaaten/bhtsne
        - "bhtsne"         : https://github.com/dominiek/python-bhtsne
        - "multicore"      : https://github.com/DmitryUlyanov/Multicore-TSNE
        - "sklearn"        : scikit-learn

        Only use `"multicore"` and `"bhtsne"` when in installed, such as in the
        `scc` environment on helix.  `"bhtsne_lvdm"` is should exist as a
        submodule, but *cannot be run in an iPython/Jupyter notebook*; use
        `"bhtsne"` instead in that case.

    ncores : int, optional
        Specifies the number of cores to use for multicore implementations.
        Ignored for algorithms that don't use it.

    ndims : int, optional (default 3)
        Specifies the number of dimensions to embed into.

    niter : int, optional (default 2500)
        Specifies the number of iterations.
        Ignored for algorithms that don't use it.
    """
    mods = {"bhtsne_lvdm": _bh_tsne_lvdm,
            "bhtsne": _bh_tsne,
            "multicore": _multicore_tsne,
            "sklearn": _sklearn_tsne}
    mod_params = {"bhtsne_lvdm": dict(use_pca=False, niter=niter,
                                      randseed=RANDOMSTATE.get_seed(),
                                      no_dims=ndims),
                  "bhtsne": dict(rand_seed=RANDOMSTATE.get_seed(),
                                 dimensions=ndims),
                  "multicore": dict(random_state=RANDOMSTATE.get_seed(),
                                    n_jobs=ncores, n_iter=niter,
                                    n_components=ndims),
                  "sklearn": dict(random_state=RANDOMSTATE, n_iter=niter,
                                  n_components=ndims)}

    tsne_func = mods[tsne_mod]
    tsne_params = mod_params[tsne_mod]
    tsne_params.update(kwargs)

    # TODO convert this to annpy dataframe
    if genes is not None:
        data = data.loc[genes]
    X = data.T.values
    embedding = tsne_func(X, **tsne_params)

    cols = [f'V{k}' for k in range(1, ndims+1)]
    return pd.DataFrame(embedding, index=data.columns, columns=cols)


def run_umap(data, genes, ndims=3, **kwargs):
    umap_params = dict(random_state=RANDOMSTATE, n_neighbors=5,
                       min_dist=0.001, metric='euclidean')
    umap_params['n_components'] = kwargs.get('n_components', ndims)
    umap_params.update(kwargs)

    embedding = UMAP(**umap_params).fit_transform(data.loc[genes].T.values)

    cols = [f'V{k}' for k in range(1, ndims+1)]
    return pd.DataFrame(embedding, index=data.columns, columns=cols)


def run_pca(data, genes, n_components=50):
    """
    Returns data transformed into `n_components` feature space and explained
    variance.
    """
    sklearn_pca = sklearnPCA(n_components=n_components)
    Y_sklearn = sklearn_pca.fit_transform(data.ix[genes].T)
    explained_variance = np.cumsum(explained_variance_ratio_) * 100

    pca_data = pd.DataFrame(Y_sklearn, index=data.columns)

    return pca_data, explained_variance


def run_dbscan(data, eps=3, min_cells=30, ncores=1, out_col='dbCluster', **kwargs):
    kwargs['min_samples'] = kwargs.get('min_samples', min_cells)
    kwargs['eps'] = kwargs.get('eps', eps)
    kwargs['n_jobs'] = kwargs.get('n_jobs', ncores)

    db = DBSCAN(**kwargs).fit(data.values)
    data[out_col] = db.labels_ + 1
    return data


def run_hdbscan(data, min_cells=30, ncores=1, out_col='dbCluster', **kwargs):
    kwargs['min_cluster_size'] = kwargs.get('min_cluster_size', min_cells)
    kwargs['min_samples'] = 10
    kwargs['core_dist_n_jobs'] = kwargs.get('core_dist_n_jobs', ncores)

    hdb = HDBSCAN(**kwargs).fit(data.values)
    data[out_col] = hdb.labels_ + 1
    return data


class SweepClusterer(object):
    """
    Weird little class to run a clusterer on a set of data with different
    parameters and find the best set of parameters for that data.

    This is the base class, which will be pretty complicated in order for the
    derived classes to be simpler.  Pass it a `sklearn.cluster`-like object and
    a dictionary of parameters to tune with either min, max, or a range.
    """
    def __init__(self, clusterer, tunables=dict()):
        self.clusterer = clusterer
        self.tunables = tunables
        self.default_tunables = dict()

        self.max_param_steps = 50
        self._validate_params()

    def _validate_params(self):
        # test object
        params = self.clusterer().get_params()
        new_tunables = dict()
        for param, vals in self.tunables.items():
            assert param in params, (f"Parameter {param} is not an acceptable "
                                     f"parameter of {self.clusterer}.")

            vals = tuple(vals)
            if len(vals) in (2, 3):
                # assume min/max given
                if len(vals) == 2:
                    diff = vals[1] - vals[0]
                    steps = diff + 1 if diff < self.max_param_steps \
                                     else self.max_param_steps
                else:
                    steps = vals[2]
                new_tunables[param] = np.linspace(vals[0], vals[1], steps)
            elif isinstance(vals, list) or isinstance(vals, tuple):
                new_tunables[param] = vals
            else:
                # assume value is None so put some defaults?
                vals = self.default_tunables.get(param, None)
                if vals is None:
                    default = self.params.get(param)
                    vals = np.linspace(0.75 * default, 1.25 * default,
                                       self.max_param_steps)

        self.tunables.update(new_tunables)

    def _find_best_params(self, param_keys, product_results):
        results = pd.DataFrame(product_results,
                               columns=list(param_keys) + ['unclustered'])
        self.params_tested = results
        min_unclustered = results.unclustered.min()
        min_results = results[results.unclustered == min_unclustered]
        best_params = min_results.sort_values('min_samples').iloc[-1]

        self.best_params = best_params.to_dict()
        return self.best_params

    def sweep(self, data, save_labels=False):
        if isinstance(data, pd.DataFrame):
            data = data.values

        n_params = len(self.tunables)
        results = []

        params = tuple(self.tunables)
        n_combos = np.prod(tuple(map(len, self.tunables.values())))
        print(f"Sweeping values of {len(params)} parameters: {params}")
        for param in params:
            print(f"{param}: {self.tunables[param][0]} - "
                  f"{self.tunables[param][-1]}")
        print(f"Attempting {n_combos} parameter combinations...")

        label_array = {}
        for value_combo in product(*self.tunables.values()):
            param_combo = dict(zip(params, value_combo))
            instance = self.clusterer(**param_combo).fit(data)

            labels = instance.labels_
            if save_labels:
                label_array[value_combo] = labels + 1
            unclustered = sum(labels == -1)
            results.append(tuple(param_combo.values()) + (unclustered,))

        if save_labels:
            label_frame = pd.DataFrame(label_array)
            #label_frame.columns.names = params
            label_frame.columns = [f'dbCluster.{k}' for k in range(n_combos)]
            self.labels = label_frame

        self._find_best_params(params, results)
        return self.best_params


class DBSCANSweeper(SweepClusterer):
    def __init__(self, tunables=dict()):
        params = dict(min_samples=(5, 40),
                      eps=(0.5, 5, 10))
        params.update(tunables)
        super().__init__(DBSCAN, params)


class HDBSCANSweeper(SweepClusterer):
    def __init__(self, tunables=dict()):
        params = dict(min_cluster_size=(5, 50, 10),
                      min_samples=(1, 50, 11))
        params.update(tunables)
        super().__init__(HDBSCAN, params)
