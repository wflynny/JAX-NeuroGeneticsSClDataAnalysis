# numpy/pandas axes
PER_CELL = 0
PER_GENE = 1


RANDSEED = 30308891
