import numpy as np


np.warnings.filterwarnings('ignore')


def exp_mean(x):
    return(np.log1p(np.mean(np.expm1(x))))


def get_ensid(feature_data, gene):
    gene = gene.capitalize()
    mask = feature_data['Associated.Gene.Name'] == gene
    if not mask.any():
        raise Exception(f"Gene {gene} not found in feature data!")
    return feature_data[mask].index[0]
