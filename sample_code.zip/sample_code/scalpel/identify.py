from .common import *

from sklearn import metrics, mixture


def find_markers_by_auc(cpt, cells1, cells2, genes):
    auc_scores = []
    truth = np.repeat([0, 1], (len(cells2), len(cells1)))
    for gene in genes:
        # think  this can be done with
        # metrics.roc_auc_curve(truth, pred) as long as truth is binary [0,1]
        pred = np.concatenate((cpt.loc[gene,cells2], cpt.loc[gene,cells1]))
        auc_scores.append(metrics.roc_auc_score(truth, pred))
        #fpr, tpr, thresholds = metrics.roc_curve(truth, pred, pos_label=2)
        #aucScores.append(metrics.auc(fpr, tpr))
    return pd.DataFrame(auc_scores, index=genes, columns=['Score'])


def identify_markers(cpt, cluster_data, feature_data,
                     fold_change_threshold=1.):
    """
    This function attempts to find genes that are expressed differentially
    between clusters.  Currently, it does so using a "one vs. all" approach
    where a gene is considered a marker for cluster k if it is more often
    expressed in cluster k than in any other cluster.  This is computed by area
    under the receiver operator curve (AUROC) constructed by considering
    expression in cluster k a "true positive" and expression in other clusters
    "false positives".

    Currently, only genes with fold change expression above
    `fold_change_threshold` are considered for marker gene identification.
    """
    auc_scores = pd.DataFrame()

    max_cluster = cluster_data['dbCluster'].max()
    for cluster in range(1, max_cluster+1):
        cells1 = cluster_data[cluster_data['dbCluster'] == cluster].index
        cells2 = cluster_data.index.difference(cells1)

        data1 = cpt.loc[cpt.index, cells1].apply(exp_mean, axis=PER_GENE)
        data2 = cpt.loc[cpt.index, cells2].apply(exp_mean, axis=PER_GENE)
        total_diff = (data1 - data2)
        genes = total_diff[total_diff > fold_change_threshold].index

        if len(genes) > 0:
            scores = find_markers_by_auc(cpt, cells1, cells2, genes)
            scores['Associated.Gene.Name'] = feature_data['Associated.Gene.Name']
            scores['dbCluster'] = cluster
            scores['avgDiff'] = total_diff
            # this is a dataframe, so append is not inplace (as is the case with
            # lists)
        else:
            scores = pd.DataFrame([], index=[],
                                  columns=['Associated.Gene.Name', 'dbCluster', 'avgDiff', 'Score'])
        auc_scores = auc_scores.append(scores)

    return auc_scores


def classify_cells(cpt, genes):
    classified = pd.DataFrame(index=genes, columns=cpt.columns)
    for gene in genes:
        X = np.asarray([cpt.loc[gene, :].values]).T
        gmm = mixture.GaussianMixture(n_components=2, covariance_type='full').fit(X)
        classified.loc[gene, :] = gmm.predict(X)

    return classified.T
