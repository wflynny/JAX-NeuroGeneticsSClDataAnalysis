"""
This module provides functionality to read and write 10X and RDS files
"""
from .common import *

from scipy.io import mmread, mmwrite
from scipy.sparse import csr_matrix

import rpy2.robjects as robjects
from rpy2.robjects import pandas2ri
from rpy2.robjects.packages import importr


NOTEBOOK_DIR_STRUCT = False
DATA_DIRECTORY = ""


def _make_rds(log2cpm, feature_data, tsne_data, outpath):
    # seperate function to contain rpy2 calls
    pandas2ri.activate()

    r_log2cpm = pandas2ri.py2ri(log2cpm)
    r_feature_data = pandas2ri.py2ri(feature_data)
    r_tsne_data = pandas2ri.py2ri(tsne_data)

    # note that rpy2 doesn't have a way to control "stringsAsFactors", so it
    # automatically converts hyphens ('-') in colnames to periods ('.'). To work
    # around that, we gsub the column names.  This only affects column names,
    # and the column names of tsne.data and featuredata don't have any hyphens.
    robjects.r('''
    rds_save <- function(log2cpm, featuredata, tsne.data, outfile) {
        colnames(log2cpm) <- gsub(".", "-", colnames(log2cpm), fixed = T)
        save(log2cpm, featuredata, tsne.data, file=outfile)
    }''')

    rds_save = robjects.globalenv['rds_save']
    rds_save(r_log2cpm, r_feature_data, r_tsne_data, outpath)


def write_rds(cpt, feature_data, tsne_data, counts, outdir):
    """
    Write count, feature, t-SNE, and cluster information to Rds file to be used
    in CellView.

    Parameters
    ----------
    cpt : pd.DataFrame
        Normalized counts

    feature_data : pd.DataFrame
        Feature data

    tsne_data : pd.DataFrame
        t-SNE data

    counts : pd.DataFrame
        Raw counts

    outdir : str

    Returns
    -------
    None
    """
    counts = counts.loc[cpt.index, cpt.columns]

    genes_detected = (counts >= 1.).sum()
    umi_counts = counts.sum()

    gene_umis = pd.DataFrame(data=list(zip(genes_detected, umi_counts)),
                             index=cpt.columns,
                             columns=['Genes', 'Transcripts'])

    umi_upper_limit = umi_counts.quantile(q=0.99)
    umi_counts[umi_counts > umi_upper_limit] = umi_upper_limit
    gene_upper_limit = genes_detected.quantile(q=0.99)
    genes_detected[genes_detected > gene_upper_limit] = gene_upper_limit
    genes_umis = pd.DataFrame(list(zip(genes_detected[cpt.columns],
                                       umi_counts[cpt.columns])),
                              columns=['ENSGGENES', 'ENSGUMI'],
                              index=cpt.columns)
    exp_out = cpt.append(genes_umis.T)

    feature_data['Chromosome.Name'] = 1
    feature_data.ix['ENSGGENES'] = ['GENES', 1]
    feature_data.ix['ENSGGUMI'] = ['Umi', 1]

    outpath = os.path.join(outdir, 'Data.Rds')
    _make_rds(exp_out, feature_data, tsne_data, outpath)


def read_10X(path, leave_sparse=False):
    """
    Reads 10X `matrix.mtx`, `genes.tsv`, and `barcodes.tsv` files returning two
    dataframes.

    Parameters
    ----------
    path : str
        String to the data directory which must contain `matrix.mtx`,
        `genes.tsv`, and `barcodes.tsv`.


    Returns
    -------
    counts : pd.DataFrame (n_genes, n_cells)
        The uncompressed counts matrix

    feature_data : pd.DataFrame (n_genes, 1)
        Feature DataFrame with index containing ENSGIDs and the other column
        containing the associated gene names


    Notes
    -----
    This will method will try to infer the global directory structure
    surrounding the path supplied.  In particular, it wants to know if the
    directory structure is in the format:

        |-- Data/
        |---- barcodes.tsv
        |---- genes.tsv
        |---- matrix.mtx
        |-- Figures/
        |-- ...

    If so, this information is stored globally and used for other save
    functions.
    """
    global DATA_DIRECTORY
    global NOTEBOOK_DIR_STRUCT
    DATA_DIRECTORY = path
    NOTEBOOK_DIR_STRUCT = is_notebook_dir_struct(path)

    mat = mmread(os.path.join(path, 'matrix.mtx'))

    genes_path = os.path.join(path, 'genes.tsv')
    feature_data = pd.read_csv(genes_path, header=None, index_col=0, sep='\t',
                               names=['Associated.Gene.Name'])

    barcodes_path = os.path.join(path, 'barcodes.tsv')
    barcodes = pd.read_csv(barcodes_path, header=None, index_col=0, sep='\t')

    index = feature_data.index
    columns = barcodes.index
    if leave_sparse:
        counts = pd.SparseDataFrame(mat, index=index, columns=columns)
    else:
        counts = pd.DataFrame(mat.todense(), index=index, columns=columns)

    return counts, feature_data


def write_10X(outdir, cpt, counts):
    with open(outdir, '/matrix.matrix', 'w') as fout:
        sparse_matrix = csr_matrix(counts)
        mmwrite(fout, sparse_matrix)

    pd.Series(counts.columns).to_csv(outdir + '/barcodes.tsv', index=False)


def is_notebook_dir_struct(path):
    # support Mohan style ../Data/, ../Notebooks/, ../Figures/, etc. style
    return os.path.exists(os.path.join(path, '../Data'))


def savefig(fig, filename, dpi=300, format='pdf'):
    """
    Generic method to save figures to a specific path.  If the global variable
    `NOTEBOOK_DIR_STRUCT == True`, which is inferred by `read_10X`, then it will
    attempt to save the figure to `DATA_DIRECTORY/../Figures/filename`.

    Parameters
    ----------
    fig : matplotlib.pyplot.Figure
        The Figure object returned by a plotting routine.

    filename : str
        Filename underwhich to save the figure.


    Returns
    -------
    None
    """
    if NOTEBOOK_DIR_STRUCT:
        prepath = os.path.join(DATA_DIRECTORY, '..', 'Figures')
    else:
        prepath = DATA_DIRECTORY
    outpath = os.path.join(prepath, filename)
    fig.savefig(outpath, format=format, dpi=dpi)
    print(f"Figure saved to [{outpath}].")


def write_auc_to_excel(auc_scores, tsnedata_dbscan, outname):
    """
    Writes AUC marker scores to an Excel file.

    Parameters
    ----------
    auc_scores : pd.DataFrame

    outname : str
    """
    #max_cluster = auc_scores['dbCluster'].max()
    max_cluster = tsnedata_dbscan['dbCluster'].max()
    sort_params = dict(by='avgDiff', ascending=False)
    #print(max_cluster)
    #print(auc_scores['dbCluster'].value_counts().sort_index().index)

    outpath = os.path.join(DATA_DIRECTORY, outname)
    with pd.ExcelWriter(outpath) as writer:
        for cluster in range(1, max_cluster+1):
            mask = auc_scores['dbCluster'] == cluster
            name = f'Cluster {cluster}'
            auc_scores.loc[mask].sort_values(**sort_params).to_excel(writer,
                                                                     name)
        writer.save()
    print(f"Scores saved to [{outpath}].")


def compute_mean_expression(cpt, tsnedata_dbscan, feature_data):
    clusters_all = [tsnedata_dbscan[tsnedata_dbscan['dbCluster'] == i].index
                    for i in tsnedata_dbscan['dbCluster'].value_counts().sort_index().index]

    print(tsnedata_dbscan['dbCluster'].min())
    print(tsnedata_dbscan['dbCluster'].max())
    print(tsnedata_dbscan['dbCluster'].value_counts())
    outpath = os.path.join(DATA_DIRECTORY, 'MeanExpression.xlsx')
    with pd.ExcelWriter(outpath) as writer:
        mean_expression = pd.DataFrame(index=cpt.index)
        mean_expression['Associated.Gene.Name'] = feature_data['Associated.Gene.Name']
        for i, c in enumerate(clusters_all, start=0):
            mean_expression.loc[:, 'Cluster%d'%i] = cpt[c].mean(axis=1)
            #meanExpression.rename(columns={0:'Mean expression'},inplace=True)
            #meanExpression.sort_values(by='Mean expression',ascending=False,inplace=True)
            #meanExpression=meanExpression[meanExpression['Mean expression']>0]
            #meanExpression['Associated.Gene.Name']=featureData['Associated.Gene.Name']
        mean_expression.to_excel(writer, 'Cluster-%d'%i)
        writer.save()



def read_10X_h5(path, reference):
    import h5py as h5
    ##import .cr_constants as crc

    #gene_ids = list(getattr(group, crc.H5_GENE_IDS_ATTR).read())
    #if hasattr(group, crc.H5_GENE_NAMES_ATTR):
    #    gene_names = list(getattr(group, crc.H5_GENE_NAMES_ATTR).read())
    #else:
    #    gene_names = gene_ids

    #assert len(gene_names) == len(gene_ids)
