"""
"""
from .common import *

from statsmodels.robust.scale import mad


def filter_cells(counts, min_count=500):
    """
    Remove cells with fewer than `min_count` genes expressed
    """
    cell_counts = counts.sum(axis=PER_CELL)
    keep_cells = cell_counts[cell_counts >= min_count].index

    return keep_cells

def filter_genes(counts, min_count=2):
    """
    Keep genes with at least `min_count` counts in at least `min_count` cells
    """
    gene_counts = (counts >= min_count).sum(axis=PER_GENE)
    keep_genes = counts.index[gene_counts >= min_count]

    return keep_genes

def median_umis_per_cell(counts):
    return np.median(counts.sum(axis=PER_CELL))

def median_genes_per_cell(counts):
    return np.median((counts >= 1.).sum(axis=PER_CELL))

def normalize_expression(counts, min_cell_count=500, min_gene_count=2):
    """
    1. Construct gene and cell masks
    2. Divide counts by total counts per cell then scale by median counts per
    cell
       This makes counts per cell equal.
    3. Take ln(counts + 1)
    """
    keep_cells = filter_cells(counts, min_count=min_cell_count)
    keep_genes = filter_genes(counts, min_count=min_gene_count)
    umi_counts = counts.sum(axis=PER_CELL)

    cpt = counts * np.median(umi_counts) / umi_counts
    cpt = cpt.loc[keep_genes, keep_cells]
    #FIXME? log or log2?  log is nice because logp1 is super fast
    cpt = cpt.apply(np.log1p)

    return cpt


def find_overdispersed_genes(cpt, N, nbins=20):
    # TODO: Understand where this idea comes from, i.e., why do this specific
    # prescription?
    mean_expression = np.log1p(np.mean(np.expm1(cpt), axis=PER_GENE))
    #FIXME? should the dispersion be a log or log1p?
    dispersion = np.log(np.var(np.expm1(cpt), axis=PER_GENE) / \
                        np.expm1(mean_expression))

    bins = np.linspace(min(mean_expression), max(mean_expression), nbins)
    pos = np.digitize(mean_expression, bins)

    overdispersion = []
    for index, gene in enumerate(mean_expression.index):
        median_bin = dispersion[pos == pos[index]].median()
        mad_bin = mad(dispersion[pos == pos[index]])
        normalized_dispersion = abs(dispersion.loc[gene] - median_bin) / mad_bin
        overdispersion.append([gene, normalized_dispersion])

    overdispersion = pd.DataFrame(overdispersion, columns=['gene', 'dispersion'])
    overdispersion.set_index('gene', inplace=True)
    top_genes = overdispersion.sort_values('dispersion',
                                           ascending=False).index[:N]

    return top_genes

def find_variable_genes(cpt, N):
    variance = cpt.var(axis=PER_GENE)
    top_genes = variance.sort_values(ascending=False).index[:N]

    return top_genes
