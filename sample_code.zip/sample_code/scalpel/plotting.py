"""
"""
from .common import *

import matplotlib
import matplotlib.pyplot as plt
from matplotlib import colors as mcolors
from matplotlib import patches as mpatches
import seaborn as sns

import plotly.plotly as pltly
from plotly.offline import download_plotlyjs, init_notebook_mode, plot, iplot, \
                           plot_mpl
from plotly.graph_objs import Scatter3d, Data, Marker, Layout, Figure, Scene, \
                              XAxis, YAxis, ZAxis

COLORS = list(map(mcolors.to_hex, plt.cm.tab20.colors))

def set_plotting_style():
    matplotlib.rcParams['axes.edgecolor'] = 'black'
    matplotlib.rcParams['axes.facecolor'] = 'white'
    matplotlib.rcParams['axes.linewidth'] = 2
    matplotlib.rcParams['axes.spines.top'] = 'off'
    matplotlib.rcParams['axes.spines.right'] = 'off'


def plot_qc(counts):
    genes_detected = (counts >= 1.).sum()
    umi_counts = counts.sum(axis=PER_CELL)

    fig, (ax1, ax2) = plt.subplots(1, 2, figsize=(10,5))

    colors = iter(plt.cm.tab10.colors)
    line_params = dict(ls='--', lw=1, color='black')
    hist_params = dict(lw=0, kind='hist')

    gene_max = (genes_detected.max() // 100 + 1) * 100
    bins = np.arange(0, gene_max, 100)
    genes_detected.plot(bins=bins, ax=ax1, color=next(colors), **hist_params)
    ax1.axvline(x=np.median(genes_detected), **line_params)
    ax1.set_xlabel('Genes', fontsize=13)
    ax1.set_ylabel('Cells', fontsize=13)

    umi_max = (umi_counts.max() // 1000 + 1) * 1000
    bins = np.arange(0, umi_max, 500)
    umi_counts.plot(bins=bins, ax=ax2, color=next(colors), **hist_params)
    ax2.axvline(x=np.median(umi_counts), **line_params)
    ax2.set_xlabel('Transcripts - UMI', fontsize=13)
    ax2.set_ylabel('Cells', fontsize=13)

    for ax in (ax1, ax2):
        ax.grid('off')
        ax.patch.set_facecolor('white')

    return fig


def plot_qc_violins(tsnedata_dbscan, counts):
    colors = COLORS #plt.cm.tab20.colors
    colors=['#000000','#a6cee3','#1f78b4','#b2df8a','#33a02c','#fb9a99','#e31a1c','#fdbf6f','#ff7f00','#cab2d6',
            '#6a3d9a','#ffff99','#b15928','#000000','#bdbdbd','#ffff99']
    colors = colors * 3
    def _violins(data, names, nbins, label):
        fig, ax = plt.subplots()

        locs = list(range(1, nbins, 1))
        vplots = ax.violinplot(data, locs, points=200, vert=True, widths=0.9,
                               showmeans=False, showextrema=False,
                               showmedians=True, bw_method=0.5)

        ax.locator_params(axis='x', nbins=nbins)
        ax.set_xticks(locs)
        ax.set_xticklabels(names, fontsize=14.,rotation=90)
        ax.set_ylabel(label, fontsize=14)
        ax.tick_params(axis='both', which='major', labelsize=14)
        ax.grid('off')
        ax.patch.set_facecolor('white')

        for patch, color in zip(vplots['bodies'], colors):
            patch.set_color(color)
            patch.set_alpha(0.8)
            patch.set_linewidths(1.5)
            patch.set_edgecolor('black')

        vplots['cmedians'].set_edgecolor('black')
        vplots['cmedians'].set_linewidths(3.)
        fig.tight_layout()

        return fig

    genes_detected = (counts >= 1.).sum(axis=PER_CELL)
    umi_counts = counts.sum(axis=PER_CELL)
    clusters_all = [tsnedata_dbscan[tsnedata_dbscan['dbCluster'] == i].index
                    for i in tsnedata_dbscan['dbCluster'].value_counts().sort_index().index]

    umi_data = [umi_counts] + [umi_counts[c] for c in clusters_all]
    names = ['AllCells'] + ['Cluster-%d'%i for i in range(0, len(clusters_all), 1)]
    nbins = len(clusters_all) + 2
    fig1 = _violins(umi_data, names, nbins, 'Transcripts Detected')

    gene_data = [genes_detected] + [genes_detected[c] for c in clusters_all]
    fig2 = _violins(gene_data, names, nbins, 'Genes Detected')

    return fig1, fig2


def plot_expression(cpt, redux_data, feature_data, genes=[],
                    dim1='V1', dim2='V2', title_prefix=''):

    fig, ax = plt.subplots()
    scatt_params = dict(s=10, vmin=0.1, vmax=2.0, linewidths=0,
                        cmap=plt.cm.Greens)

    if genes:
        if isinstance(genes, str):
            genes = [genes]
        gene_ids = [get_ensid(feature_data, gene) for gene in genes]
        cdata = cpt.loc[gene_ids, ].mean(axis=PER_CELL).values
        ax.set_title(f'{title_prefix} ' + ', '.join(genes))
    else:
        cdata = cpt.mean(axis=1).values
        ax.set_title(f'{title_prefix} ' + 'All genes')
    scatt_params.update(dict(c=cdata))

    #TODO: Needs legend

    acceptable_dims = ('V1', 'V2', 'V3')
    if dim1 not in acceptable_dims or dim2 not in acceptable_dims:
        print(f"Dimensions should be two of {acceptable_dims}")
        dim1, dim2 = 'V1', 'V2'

    scatt = ax.scatter(redux_data[dim1], redux_data[dim2], **scatt_params)
    fig.colorbar(scatt, label='log(expression)')

    return fig


def plot_clusters(cluster_data, dim1, dim2):
    n_clusters = len(cluster_data.dbCluster.unique())
    colors = plt.cm.tab20.colors[::max(1, 20//n_clusters)]
    colors=['#a6cee3','#1f78b4','#b2df8a',
        '#33a02c','#fb9a99','#e31a1c',
        '#fdbf6f','#ff7f00','#cab2d6',
        '#6a3d9a','#ffff99','#b15928',
       '#000000','#bdbdbd','#ffff99']

    #fig, ax = plt.subplots()
    #ax.set_aspect('equal')
    #scatt_params = dict(s=5, linewidths=0, cmap=plt.cm.tab20)
    #ax.scatter(cluster_data.loc[:, dim1], cluster_data.loc[:, dim2],
    #           c=cluster_data.loc[:, 'dbCluster'], **scatt_params)

    # reserve light blue for unclustered
    if cluster_data.dbCluster.min() > 0:
        colors = colors[1:]

    fig = sns.lmplot(dim1, dim2, data=cluster_data, hue='dbCluster',
                     fit_reg=False, palette=colors, scatter_kws={'s': 5})
    fig.ax.grid('off')
    fig.ax.patch.set_facecolor('white')
    return fig


def plot_clusters_3d(cluster_data, title=''):
    init_notebook_mode()

    walkers = []
    colors = COLORS * 3 #plt.cm.tab20.colors * 3
    colors=['#a6cee3','#1f78b4','#b2df8a','#33a02c','#fb9a99','#e31a1c','#fdbf6f','#ff7f00','#cab2d6',
            '#6a3d9a','#ffff99','#b15928','#000000','#bdbdbd','#ffff99']
    colors=colors*3

    # FIXME: why 44?
    for k in range(0,44,1):
        tsne_subset = cluster_data[cluster_data['dbCluster'] == k]

        cell_names = tsne_subset.index
        x = tsne_subset['V1'].values
        y = tsne_subset['V2'].values
        z = tsne_subset['V3'].values
        marker_dict = dict(color=colors[k], size=3, symbol='circle',
                           line=dict(color=colors[k], width=0))

        trace = Scatter3d(x=x, y=y, z=z, name=k, mode='markers',
                          text=['Cell Name: %s'%i for i in cell_names],
                          marker=marker_dict)
        walkers.append(trace)
    data = Data(walkers)

    axis_params = dict(showgrid=True, zeroline=True, showticklabels=True)
    layout = Layout(title=title, hovermode='closest',
                    xaxis=dict(title='DIM-1', ticklen=0,
                               showline=True, zeroline=True),
                    yaxis=dict(title='DIM-2', ticklen=5),
                    scene=Scene(xaxis=XAxis(title='DIM-1', **axis_params),
                                yaxis=YAxis(title='DIM-2', **axis_params),
                                zaxis=ZAxis(title='DIM-3', **axis_params)))

    fig = Figure(data=data, layout=layout)
    #plot(fig, filename=outpath, image='png', validate=False)
    iplot(fig)#, filename=outpath, image='png', validate=False)


def plot_marker_heatmap(cpt, auroc_scores, tsnedata_dbscan, feature_data):
    #colors = plt.cm.tab20.colors
    #colors = COLORS * 2
    colors=['#a6cee3','#1f78b4','#b2df8a','#33a02c','#fb9a99','#e31a1c','#fdbf6f','#ff7f00','#cab2d6',
                '#6a3d9a','#ffff99','#b15928','#000000','#bdbdbd','#ffff99']
    colors=colors+colors+colors

    df3 = auroc_scores[~auroc_scores.index.duplicated(keep='first')]

    color_func = lambda x, df: colors[df.loc[x, 'dbCluster']]
    hdata = cpt.loc[df3.index, tsnedata_dbscan.sort_values('dbCluster').index]
    col_colors = hdata.columns.map(lambda x: color_func(x, tsnedata_dbscan))
    row_colors = hdata.index.map(lambda x: color_func(x, df3))

    heatmap = sns.clustermap(hdata, z_score=0, vmin=-3, vmax=3, cmap='vlag',
                             xticklabels=False, yticklabels=False,
                             row_cluster=False, col_cluster=False,
                             col_colors=col_colors, row_colors=row_colors,
                             metric='correlation')
    heatmap.ax_heatmap.set_xlabel('Cells', fontsize=14)
    heatmap.ax_heatmap.set_ylabel('Marker genes', fontsize=14)

    leg_handles = []
    plotted_colors = colors[1:tsnedata_dbscan['dbCluster'].max() + 1]
    for cluster, color in enumerate(plotted_colors, start=1):
        leg_handles.append(mpatches.Patch(color=color, label='Cluster-%s'%cluster))

    legend_params = dict(loc='center left', ncol=1, bbox_to_anchor=(1.23, 0.5),
                         handletextpad=0.1, labelspacing=0.2, prop=dict(size=12))
    gene_legend = heatmap.ax_heatmap.legend(handles=leg_handles,
                                            title='Cell types',
                                            **legend_params)

    return heatmap
