import numpy as np


class RandomState(np.random.RandomState):
    """
    Small wrapper around numpy.random.RandomState so that we can control the
    default random state of the various package methods that rely on randomness
    (everything in `clust_redux`), but also allow the random state to be easily
    changed.

    Added convenience methods to get the first random number from the Mersenne
    Twister PRNG and also added aliases `set_seed`, `change_seed`, and `reseed`
    which all do the same thing.

    This class isn't exposed directly, but instead through the imported global
    `RANDOMSTATE`.  This way, it is less cumbersome to change the state, e.g.

        RANDOMSTATE.reseed()
        # vs
        RandomState().reseed()
    """
    def __init__(self, start_seed=30308891):
        super(RandomState, self).__init__()
        self.seed(start_seed)

    def get_seed(self):
        return self.get_state()[1][0]

    set_seed = np.random.RandomState.seed
    change_seed = np.random.RandomState.seed
    reseed = np.random.RandomState.seed


RANDOMSTATE = RandomState()
